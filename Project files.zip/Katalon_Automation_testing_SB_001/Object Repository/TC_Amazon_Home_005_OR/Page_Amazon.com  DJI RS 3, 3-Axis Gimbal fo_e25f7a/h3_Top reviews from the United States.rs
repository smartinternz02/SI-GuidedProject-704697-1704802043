<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_Top reviews from the United States</name>
   <tag></tag>
   <elementGuidId>6d49b76e-035f-46de-9b70-549666ccd2d3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h3.a-spacing-medium.a-spacing-top-large</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='cm-cr-local-reviews-title']/h3</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>be407531-266a-4ddc-b55a-dc7cd1a4924c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-hook</name>
      <type>Main</type>
      <value>dp-local-reviews-header</value>
      <webElementGuid>7b4aec3a-869a-4971-bb08-8ae53e7a7ed9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-spacing-medium a-spacing-top-large</value>
      <webElementGuid>7eaddea7-9f8e-4d14-90f4-ffcf9cf5a19c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>










  Top reviews from the United States
</value>
      <webElementGuid>b197096c-acde-40cf-956c-44d240949ee3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;cm-cr-local-reviews-title&quot;)/h3[@class=&quot;a-spacing-medium a-spacing-top-large&quot;]</value>
      <webElementGuid>dfed5c2e-c685-40bd-93f5-8f229e128d7b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='cm-cr-local-reviews-title']/h3</value>
      <webElementGuid>ff84bf47-913e-4a20-a71b-dfcd6bc0bce5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/div/div/div/h3</value>
      <webElementGuid>929a15d6-12cf-4add-a280-2d0b23ba718c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = '










  Top reviews from the United States
' or . = '










  Top reviews from the United States
')]</value>
      <webElementGuid>f83f6410-d785-4019-9db3-9ba6b243f8af</webElementGuid>
   </webElementXpaths>
</WebElementEntity>

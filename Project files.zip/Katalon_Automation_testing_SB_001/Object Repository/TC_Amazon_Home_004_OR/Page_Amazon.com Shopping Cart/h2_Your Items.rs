<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Your Items</name>
   <tag></tag>
   <elementGuidId>55351b6a-224c-4873-adac-b048918bf220</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h2</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='sc-secondary-list']/div/div/h2</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>4c8086a8-6f2a-47d5-93cd-bd8ad0e262a5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                    Your Items
                </value>
      <webElementGuid>50cafc90-0406-4456-bbae-bfe37b68b7f4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sc-secondary-list&quot;)/div[@class=&quot;a-cardui-body a-scroller-none&quot;]/div[@class=&quot;a-row sc-list-head sc-java-remote-feature&quot;]/h2[1]</value>
      <webElementGuid>056cddf0-cd26-46d2-bc86-4f66ccab4682</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='sc-secondary-list']/div/div/h2</value>
      <webElementGuid>7f19df89-3ab2-4f2d-b6a7-1c7a342e3f49</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h2</value>
      <webElementGuid>b6a10ed4-a3cd-45a2-a701-baca5937030b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = '
                    Your Items
                ' or . = '
                    Your Items
                ')]</value>
      <webElementGuid>daf5c205-d74f-438c-8e0f-e20c963a52c1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>

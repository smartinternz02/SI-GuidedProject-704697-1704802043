<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Price</name>
   <tag></tag>
   <elementGuidId>7d8ec5c1-a271-43a8-947d-c2afadb9946f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.a-section.a-spacing-none.sc-list-head.sc-java-remote-feature > div.a-row</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='activeCartViewForm']/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>4bb748c4-0402-43b6-bce4-dd0abf2f5b0c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-row</value>
      <webElementGuid>2ba4dd15-1f9c-4d7a-8360-f1445f2bc5dc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
        
            Price
        
    </value>
      <webElementGuid>5f69db87-98df-4d17-b0c2-b67da65b1270</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;activeCartViewForm&quot;)/div[@class=&quot;a-section a-spacing-none sc-list-head sc-java-remote-feature&quot;]/div[@class=&quot;a-row&quot;]</value>
      <webElementGuid>128385db-9b7d-484a-9a2f-1d3bf37aa75b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='activeCartViewForm']/div/div</value>
      <webElementGuid>e1a63a72-9401-4720-a263-c0ae2a44aa56</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/form/div/div</value>
      <webElementGuid>e07e7990-443d-4d3e-988f-437c0b9f1aff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
        
        
            Price
        
    ' or . = '
        
        
            Price
        
    ')]</value>
      <webElementGuid>443b9428-8205-4b2b-9a36-c595d053b5cb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>

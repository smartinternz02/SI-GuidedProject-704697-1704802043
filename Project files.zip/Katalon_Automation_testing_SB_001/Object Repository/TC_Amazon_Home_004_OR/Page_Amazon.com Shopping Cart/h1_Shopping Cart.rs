<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Shopping Cart</name>
   <tag></tag>
   <elementGuidId>9a859725-3ab5-41a0-b832-4b3471095fa1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h1</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='sc-active-cart']/div/div/div/h1</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>978e8e69-1ce3-4197-9c28-b2e23f487f8d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                Shopping Cart
            </value>
      <webElementGuid>e9153c8e-c0a9-427b-ba00-644a345d6ef6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sc-active-cart&quot;)/div[@class=&quot;a-cardui-body a-scroller-none&quot;]/div[@class=&quot;a-row sc-cart-header sc-compact-bottom&quot;]/div[@class=&quot;a-row&quot;]/h1[1]</value>
      <webElementGuid>f469bd1e-7027-49e2-b520-a2ba5effce39</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='sc-active-cart']/div/div/div/h1</value>
      <webElementGuid>7750c03b-a7f2-4974-b21b-5e907af93489</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1</value>
      <webElementGuid>801c76d9-968e-4172-81a0-19b98c96471b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = '
                Shopping Cart
            ' or . = '
                Shopping Cart
            ')]</value>
      <webElementGuid>4064c15b-8998-4b84-bb0c-9d66dcb41705</webElementGuid>
   </webElementXpaths>
</WebElementEntity>

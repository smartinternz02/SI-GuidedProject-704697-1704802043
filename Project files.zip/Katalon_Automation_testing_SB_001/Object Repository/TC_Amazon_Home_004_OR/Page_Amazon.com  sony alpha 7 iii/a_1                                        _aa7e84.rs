<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_1                                        _aa7e84</name>
   <tag></tag>
   <elementGuidId>9f03e99f-8397-4bb5-be1b-17c442c74528</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#nav-cart</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='nav-cart']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>a664821c-c8f5-4290-8e5b-457291a25ee7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/gp/cart/view.html?ref_=nav_cart</value>
      <webElementGuid>194fc290-0e4c-499f-a269-0b19a41faa05</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>0 items in cart</value>
      <webElementGuid>447a3db4-58f5-4dd4-b6e2-67e5248fc8e6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-a nav-a-2 nav-progressive-attribute</value>
      <webElementGuid>493fc1cc-3338-45ff-9abb-55c1e1825cbb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>nav-cart</value>
      <webElementGuid>7ade5870-c4c7-4c98-bdf5-6e01c6d8440f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
      1
      
    
    
      
        
      
      
        Cart
        
      
    
  </value>
      <webElementGuid>07a93a74-3d98-4254-bd6b-72f119495ab1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;nav-cart&quot;)</value>
      <webElementGuid>e61e94e1-750b-4b88-8735-f1edeb7d125a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//a[@id='nav-cart']</value>
      <webElementGuid>41ec0500-ea3b-4e01-bff4-eb23c9dc3af4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='nav-tools']/a[5]</value>
      <webElementGuid>9c6e3596-34cc-417d-9452-3a19e2982d4d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/gp/cart/view.html?ref_=nav_cart')]</value>
      <webElementGuid>b22b6edd-2d49-4293-a945-06fb036ad6f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[5]</value>
      <webElementGuid>55a50b08-427a-4558-b75c-542e4a304b3d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/gp/cart/view.html?ref_=nav_cart' and @id = 'nav-cart' and (text() = '
    
      1
      
    
    
      
        
      
      
        Cart
        
      
    
  ' or . = '
    
      1
      
    
    
      
        
      
      
        Cart
        
      
    
  ')]</value>
      <webElementGuid>a483df99-8e71-419a-b699-305dfc4095dc</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
